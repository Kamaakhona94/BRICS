---
"eth-tech-tree": patch
---

updated colors for readability
