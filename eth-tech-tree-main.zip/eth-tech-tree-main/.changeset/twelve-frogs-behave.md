---
"eth-tech-tree": patch
---

Fixed a small bug when showing tree history, Also removed the (Y/n) that showed when prompted with "Press Enter to continue"
