---
"eth-tech-tree": minor
---

using create-eth extensions for challenges, bug fixes with coloring of menus and view height
