---
"eth-tech-tree": patch
---

Updating release workflow to commit package version changes
