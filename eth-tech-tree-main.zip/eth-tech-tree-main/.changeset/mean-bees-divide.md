---
"eth-tech-tree": patch
---

Readme adjustments, Challenge formats revised
