---
"eth-tech-tree": patch
---

increasing the timeout for ncp operation
