---
"eth-tech-tree": patch
---

added logging to the git commit script
