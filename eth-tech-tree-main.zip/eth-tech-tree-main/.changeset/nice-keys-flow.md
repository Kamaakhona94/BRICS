---
"eth-tech-tree": patch
---

Ask user for confirmation before resetting their challenge
