---
"eth-tech-tree": patch
---

Major UI overhaul. Everything should still work similarly to last release.
