---
"eth-tech-tree": patch
---

sort challenges, grey out challenges that don't exist, other styling changes
