---
"eth-tech-tree": patch
---

added better feedback during challenge setup
